<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Importar Arquivos</title>
  <style>
    :root{
      --bg:#0f1115;
      --panel:#151922;
      --muted:#95a1b2;
      --text:#e7ecf3;
      --primary:#5b8cff;
      --danger:#ff5c5c;
      --card:#1a2030;
      --border:#22293a;
      --shadow:0 10px 30px rgba(0,0,0,.45);
      --radius:16px;
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: var(--bg);
      color:var(--text);
      min-height:100vh;
    }
    header{
      position:sticky; top:0; z-index:10;
      background:rgba(15,17,21,.8);
      border-bottom:1px solid var(--border);
      padding:16px 20px;
      display:flex; align-items:center; gap:12px; justify-content:center;
      font-weight:700;
    }
    header .badge{
      font-weight:700; font-size:13px; padding:4px 10px; border-radius:999px;
      background: var(--primary);
      color:#0b1020;
    }
    main{max-width:1080px; margin:28px auto; padding:0 16px 80px}
    .panel{
      background:var(--panel);
      border:1px solid var(--border);
      border-radius:var(--radius);
      box-shadow:var(--shadow);
      overflow:hidden;
      padding-bottom: 20px;
    }
    .panel-header{
      padding:18px 20px;
      display:flex; align-items:center; justify-content:space-between;
      border-bottom:1px solid var(--border);
    }
    .panel-title{font-size:18px; font-weight:700}
    .btn{
      border:none; cursor:pointer; font-weight:700;
      padding:10px 14px; border-radius:12px;
      background:var(--primary); color:#0b1020;
    }
    .btn.secondary{background:#232a3b; color:var(--text); border:1px solid var(--border)}
    .btn.danger{background:var(--danger); color:#140a0a}

    /* Lista de certificados */
    .cert-list{padding:16px; display:grid; gap:12px;}
    .cert-item{
      background:var(--card); border:1px solid var(--border);
      border-radius:12px; padding:12px 16px;
    }
    .cert-item strong{display:block; font-size:16px; margin-bottom:6px}
    .cert-item small{color:var(--muted)}
    .cert-item a{display:inline-block; margin-top:8px; font-weight:700; color:var(--primary); text-decoration:none}
    .cert-item a:hover{text-decoration:underline}

    /* Modal do formulário extra */
    .form-modal{
      position:fixed; inset:0; display:none; place-items:center;
      background:rgba(0,0,0,.65); z-index:100;
    }
    .form-modal.open{display:grid}
    .form-box{
      background:#1a2030; padding:20px; border-radius:16px; width:320px;
      display:flex; flex-direction:column; gap:12px; box-shadow:var(--shadow);
    }
    .form-box h2{margin:0; font-size:18px; text-align:center}
    .form-box label{font-size:14px; font-weight:600}
    .form-box input{
      padding:8px 10px; border-radius:8px; border:1px solid var(--border);
      background:#101626; color:var(--text);
    }
    .form-actions{display:flex; justify-content:flex-end; gap:10px; margin-top:10px}
  </style>
</head>
<body>
  
  <header>
    Importar Arquivos <span class="badge">Novo</span>
  </header>

  <main>
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Meus Arquivos</span>
        <button class="btn" onclick="document.getElementById('fileInput').click()">Importar</button>
      </div>

      <!-- Lista de certificados -->
      <div class="cert-list">
      <?php
session_start();
require_once "../php/conexao.php";

$idAluno = $_SESSION['idAluno'] ?? null;

if(!$idAluno){
    echo "<p>Usuário não logado.</p>";
    exit;
}

$sql = "SELECT * FROM certificados WHERE idAluno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idAluno);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo '<div class="cert-item">';
        echo '<strong>'.htmlspecialchars($row['titulo']).'</strong>';
        echo '<small>Horas: '.$row['quantidadeHoras'].' | Data: '.$row['dataEmissao'].'</small>';
        echo '<br><a href="../'.$row['URL'].'" target="_blank">Ver Certificado</a>';

        // Botão de excluir
        echo '<form method="POST" action="../php/excluir_certificado.php" style="display:inline">';
        echo '<input type="hidden" name="idCertificado" value="'.$row['idCertificado'].'">';
        echo '<button type="submit" class="btn danger" onclick="return confirm(\'Deseja realmente excluir este certificado?\')">Excluir</button>';
        echo '</form>';

        echo '</div>';
    }
} else {
    echo "<p>Nenhum certificado encontrado.</p>";
}
?>

</div>
    </div>
  </main>

  <!-- Modal do formulário -->
  <div class="form-modal" id="formModal">
    <div class="form-box">
      <h2>Informações do Arquivo</h2>
      <form id="uploadForm" action="../php/upload.php" method="POST" enctype="multipart/form-data">
        <label>Evento</label>
        <input type="text" name="curso" id="cursoInput" required>

        <label>Horas</label>
        <input type="number" name="horas" id="horasInput" min="1" required>

        <label>Data do Evento</label>
        <input type="date" name="data" id="dataInput" required>

        <input type="file" name="arquivo" id="fileInput" style="display:none" required>

        <div class="form-actions">
          <button type="button" class="btn secondary" onclick="closeForm()">Cancelar</button>
          <button type="submit" class="btn">Salvar</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    // Abrir modal quando escolher arquivo
    document.getElementById('fileInput').addEventListener('change', e => {
      if(e.target.files.length > 0){
        document.getElementById('formModal').classList.add('open');
      }
    });

    // Fechar formulário
    function closeForm(){
      document.getElementById('formModal').classList.remove('open');
      document.getElementById('cursoInput').value = "";
      document.getElementById('dataInput').value = "";
      document.getElementById('horasInput').value = "";
      document.getElementById('fileInput').value = "";
    }
  </script>
</body>
</html>
