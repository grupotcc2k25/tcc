<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="../css/style_certificados.css">
  <meta charset="UTF-8">
  <title>Importar Arquivos</title>
 
</head>
<body>
 <!-- ================= NAVBAR ================= -->
 <nav>

<!-- Ícone menu (mobile) -->
<div class="menu-icon">
  <span class="fas fa-bars"></span>
</div>

<!-- Logo -->
<div class="logo">
  <a href="../php/paginaslide.php">SRA</a>
</div>

<!-- Itens da navegação -->
<div class="nav-items">
  <li><a href="../html/horas.php">Horas</a></li>
  <li><a href="../html/relatorio.php">Relatórios</a></li>
  <li><a href="../html/certificados.php">Certificados</a></li>
  <li><a href="../html/palestras.html">Palestras</a></li>
</div>

<!-- Ícone cancelar (mobile) -->
<div class="cancel-icon">
  <span class="fas fa-times"></span>
</div>

 <!-- ================= PERFIL (DROPDOWN) ================= -->
<div class="profile-container">
<!-- Ícone de perfil no canto superior -->
<img src="../img/relogio.png" alt="Perfil" class="profile-icon" id="profileBtn" />

<!-- Menu dropdown do perfil -->
<div class="dropdown-menu" id="dropdownMenu">
  <div class="profile-info">
    <img src="../img/relogio.png" alt="Perfil" />
    <!-- Dados dinâmicos do usuário -->
    <h3><?php echo htmlspecialchars($nome); ?></h3>
    <p>RM: <?php echo htmlspecialchars($rm); ?></p>
  </div>
  <!-- Botão de logout -->
  <a href="#" onclick="confirmarLogout()">🚪 Sair</a>
</div>
</div>

</nav>

<!-- ================= CONTEÚDO CENTRAL ================= -->
<div class="content">
<header class="space"></header>
<div class="space text"></div>
</div>

  <main>
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Meus Arquivos</span>
        <button class="btn" onclick="document.getElementById('fileInput').click()">Importar</button>
      </div>

      <!-- Lista de certificados -->
      <div class="cert-list">
      <?php
session_start();
require_once "../php/conexao.php";

$idAluno = $_SESSION['idAluno'] ?? null;

if(!$idAluno){
    echo "<p>Usuário não logado.</p>";
    exit;
}

$sql = "SELECT * FROM relatorios WHERE idAluno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idAluno);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo '<div class="cert-item">';
        echo '<strong>'.htmlspecialchars($row['titulo']).'</strong>';
        echo '<small>Horas: '.$row['quantidadeHoras'].' | Data: '.$row['dataEmissao'].'</small>';
        echo '<br><a href="../'.$row['URL'].'" target="_blank">Ver Relatório</a>';

        // Botão de excluir
        echo '<form method="POST" action="../php/excluir_relatorio.php" style="display:inline">';
        echo '<input type="hidden" name="idRelatorios" value="'.$row['idRelatorios'].'">';
        echo '<button type="submit" class="btn danger" onclick="return confirm(\'Deseja realmente excluir este relatorio?\')">Excluir</button>';
        echo '</form>';

        echo '</div>';
    }
} else {
    echo "<p>Nenhum relatorio encontrado.</p>";
}
?>

</div>
    </div>
  </main>

  <!-- Modal do formulário -->
  <div class="form-modal" id="formModal">
    <div class="form-box">
      <h2>Informações do Arquivo</h2>
      <form id="uploadForm" action="../php/upload_relatorio.php" method="POST" enctype="multipart/form-data">
        <label>Evento</label>
        <input type="text" name="curso" id="cursoInput" required>

        <label>Horas</label>
        <input type="number" name="horas" id="horasInput" min="1" required>

        <label>Data do Evento</label>
        <input type="date" name="data" id="dataInput" required>

        <input type="file" name="arquivo" id="fileInput" style="display:none" required
       accept=".txt,.pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">


        <div class="form-actions">
          <button type="button" class="btn secondary" onclick="closeForm()">Cancelar</button>
          <button type="submit" class="btn">Salvar</button>
        </div>
      </form>
    </div>
  </div>

<script src="../js/certificados.js"></script>
</body>
</html>
