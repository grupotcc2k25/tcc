<?php
// ================= INÍCIO DA SESSÃO =================
session_start();
require_once "../php/conexao.php";

// Verifica se o usuário está logado (se não houver RM na sessão)
if (!isset($_SESSION['rm'])) {
    header("Location: ../html/index.php"); // Redireciona para login
    exit();
}

// Recupera os dados da sessão
$nome = $_SESSION['nome'];
$rm   = $_SESSION['rm'];
$idAluno = $_SESSION['idAluno'] ?? null;

if(!$idAluno){
    echo "<p>Usuário não logado.</p>";
    exit;
}

// Inicializa variáveis
$dados = [];
$horasEventos = 0;
$horasCertificados = 0;
$horasRelatorio = 0;

// -------- Eventos --------
// $result = $conn->query("SELECT titulo, quantidadeHoras FROM acp WHERE idAluno = $idAluno");
// while($row = $result->fetch_assoc()){
//     $row['categoria'] = 'evento';
//     $dados[] = $row;
//     $horasEventos += (int)$row['quantidadeHoras'];
// }

$result = $conn->query("SELECT titulo, quantidadeHoras FROM certificados WHERE idAluno = $idAluno");
while($row = $result->fetch_assoc()){
    $row['categoria'] = 'certificado';
    $dados[] = $row;
    $horasCertificados += (int)$row['quantidadeHoras'];
}

// -------- Relatórios --------
 $result = $conn->query("SELECT titulo, quantidadeHoras FROM relatorios WHERE idAluno = $idAluno");
  while($row = $result->fetch_assoc()){
    $row['categoria'] = 'relatorio';
    $dados[] = $row;
    $horasRelatorio += (int)$row['quantidadeHoras'];
 }

$totalHoras = $horasEventos + $horasCertificados + $horasRelatorio;
$totalAlvo = 200;
$horasRestantes = max($totalAlvo - $totalHoras, 0);

$labelsGrafico = ['Eventos','Certificados','Relatórios'];
$dadosGrafico = [$horasEventos, $horasCertificados, $horasRelatorio];
if($horasRestantes > 0){
    $labelsGrafico[] = 'Faltante';
    $dadosGrafico[] = $horasRestantes;
}
?>

<!DOCTYPE html> 
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Horas</title>
  <link rel="stylesheet" href="../css/style_horas.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- ================= NAVBAR ================= -->
<nav>

<!-- Ícone menu (mobile) -->
<div class="menu-icon">
  <span class="fas fa-bars"></span>
</div>

<!-- Logo -->
<div class="logo">
  <a href="../php/paginaslide.php">SRA</a>
</div>

<!-- Itens da navegação -->
<div class="nav-items">
  <li><a href="../html/horas.php">Horas</a></li>
  <li><a href="../html/relatorio.php">Relatórios</a></li>
  <li><a href="../html/certificados.php">Certificados</a></li>
  <li><a href="../html/palestras.html">Palestras</a></li>
</div>

<!-- Ícone cancelar (mobile) -->
<div class="cancel-icon">
  <span class="fas fa-times"></span>
</div>

 <!-- ================= PERFIL (DROPDOWN) ================= -->
<div class="profile-container">
<!-- Ícone de perfil no canto superior -->
<img src="../img/relogio.png" alt="Perfil" class="profile-icon" id="profileBtn" />

<!-- Menu dropdown do perfil -->
<div class="dropdown-menu" id="dropdownMenu">
  <div class="profile-info">
    <img src="../img/relogio.png" alt="Perfil" />
    <!-- Dados dinâmicos do usuário -->
    <h3><?php echo htmlspecialchars($nome); ?></h3>
    <p>RM: <?php echo htmlspecialchars($rm); ?></p>
  </div>
  <!-- Botão de logout -->
  <a href="#" onclick="confirmarLogout()">🚪 Sair</a>
</div>
</div>

</nav>

<main>
<div class="panel">
  <div class="panel-header"><span class="panel-title">Minhas Horas</span></div>

<div class="content-grid">
  
  <!-- Gráfico -->
  <div class="chart-container">
    <canvas id="graficoHoras"></canvas>
  </div>

  <!-- Tabela apenas com totais -->
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>Eventos</th>
          <th>Certificados</th>
          <th>Relatórios</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><?php echo $horasEventos; ?></td>
          <td><?php echo $horasCertificados; ?></td>
          <td><?php echo $horasRelatorio; ?></td>
        </tr>
      </tbody>
    </table>
  </div>

</div>

<div style="margin-top:20px; font-weight:bold; font-size:1.2em;">
  Total de Horas: <?php echo $totalHoras; ?> / <?php echo $totalAlvo; ?>h
</div>

</div>
</main>

<script>
  // Menu mobile
  const menuIcon = document.querySelector('.menu-icon');
  const cancelIcon = document.querySelector('.cancel-icon');
  const navItems = document.querySelector('.nav-items');

  menuIcon.addEventListener('click', () => navItems.classList.add('show'));
  cancelIcon.addEventListener('click', () => navItems.classList.remove('show'));
  navItems.querySelectorAll('li a').forEach(link => {
    link.addEventListener('click', () => navItems.classList.remove('show'));
  });

  // Dropdown do perfil
  const profileBtn = document.getElementById('profileBtn');
  const dropdownMenu = document.getElementById('dropdownMenu');
  profileBtn.addEventListener('click', () => dropdownMenu.classList.toggle('show'));
  document.addEventListener('click', (e) => {
      if(!profileBtn.contains(e.target) && !dropdownMenu.contains(e.target)){
          dropdownMenu.classList.remove('show');
      }
  });

  // Função de logout
  function confirmarLogout() {
      if(confirm("Deseja realmente sair?")) window.location.href = "../php/logout.php";
  }

  // Gráfico de pizza
  const canvas = document.getElementById('graficoHoras');
  const ctx = canvas.getContext('2d');

  function ajustarCanvas() {
      const { width, height } = canvas.getBoundingClientRect();
      canvas.width = width * window.devicePixelRatio;
      canvas.height = height * window.devicePixelRatio;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }

  ajustarCanvas();
  window.addEventListener('resize', () => {
      ajustarCanvas();
      grafico.update();
  });

  const grafico = new Chart(ctx, {
      type: 'pie',
      data: {
          labels: <?php echo json_encode($labelsGrafico); ?>,
          datasets: [{
              label: 'Horas por categoria',
              data: <?php echo json_encode($dadosGrafico); ?>,
              backgroundColor: ['#FF6384','#36A2EB','#FFCE56','#DDDDDD'],
              borderColor: '#ffffffff',
              borderWidth: 1,
              hoverOffset: 15
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
              legend: { position: 'bottom', labels:{font:{size:14}} },
              tooltip: {
                  callbacks: {
                      label: function(context){
                          let label = context.label || '';
                          let value = context.raw || 0;
                          return label + ': ' + value + 'h';
                      }
                  }
              }
          },
          hover: {
              mode: 'nearest',
              onHover: function(event, chartElement){
                  event.native.target.style.cursor = chartElement.length ? 'pointer' : 'default';
              }
          }
      }
  });
</script>

</body>
</html>