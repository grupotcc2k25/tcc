<?php
session_start();
require_once "conexao.php";
require_once "../vendor/autoload.php";

use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader\PdfReaderException;

$idAluno = $_SESSION['idAluno'] ?? null;
$nomeAluno = $_SESSION['nome'] ?? 'Aluno';

if(!$idAluno){
    http_response_code(401);
    exit("Usuário não logado.");
}

$sql = "SELECT * FROM certificados WHERE idAluno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idAluno);
$stmt->execute();
$result = $stmt->get_result();

$pdf = new Fpdi();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, "Portfólio de Certificados - $nomeAluno", 0, 1, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 12);

while ($row = $result->fetch_assoc()) {
    $titulo = $row['titulo'];
    $data   = $row['dataEmissao'];
    $horas  = $row['quantidadeHoras'];
    $instituicao = $row['instituicao'];
    $urlArquivo  = "../" . $row['URL'];
    $ext = strtolower(pathinfo($urlArquivo, PATHINFO_EXTENSION));

    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 8, $titulo, 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 6, "Data: $data", 0, 1);
    $pdf->Cell(0, 6, "Horas: $horas", 0, 1);
    $pdf->Cell(0, 6, "Instituição: $instituicao", 0, 1);
    $pdf->Ln(5);

    if ($ext === 'pdf') {
        try {
            $pageCount = $pdf->setSourceFile($urlArquivo);
            for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                $templateId = $pdf->importPage($pageNo);
                $pdf->AddPage();
                $pdf->useTemplate($templateId);
            }
        } catch (PdfReaderException $e) {
            $pdf->SetFont('Arial', 'I', 10);
            $pdf->Cell(0, 10, "Erro ao carregar PDF: {$e->getMessage()}", 0, 1);
        }
    } elseif (in_array($ext, ['jpg', 'jpeg', 'png'])) {
        if (file_exists($urlArquivo)) {
            $pdf->AddPage();
            $pdf->Image($urlArquivo, 10, 10, 180);
        } else {
            $pdf->Cell(0, 10, "Imagem não encontrada: $urlArquivo", 0, 1);
        }
    } else {
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 10, "Tipo de arquivo não suportado: $ext", 0, 1);
    }
}

$pdf->Output("I", "portifolio_certificados.pdf");
