<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="../css/style_certificados.css">
  <meta charset="UTF-8">
  <title>Importar Arquivos</title>
 
</head>
<body>
   <div class="profile-container">
      <img src="../img/relogio.png" alt="Perfil" class="profile-icon" id="profileBtn" />
      <div class="dropdown-menu" id="dropdownMenu">
        <div class="profile-info">
          <img src="../img/relogio.png" alt="Perfil" />
          <h3><?php echo htmlspecialchars($nome); ?></h3>
          <p>RM: <?php echo htmlspecialchars($rm); ?></p>
        </div>
        
        <a href="#" onclick="confirmarLogout()">🚪 Sair</a>
      </div>
    </div>

    <nav>
      <div class="menu-icon">
        <span class="fas fa-bars"></span>
      </div>

      <div class="logo">
        <a href="../php/paginaslide.php">SRA</a>
      </div>

      <div class="nav-items">
        <li><a href="../html/horas.html">Horas</a></li>
        <li><a href="../html/relatorio.html">Relatórios</a></li>
        <li><a href="../html/certificados.php">Certificados</a></li>
        <li><a href="../html/palestras.html">Palestras</a></li>
      </div>

      <div class="cancel-icon">
        <span class="fas fa-times"></span>
      </div>
    </nav>

  <main>
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Meus Arquivos</span>
        <button class="btn" onclick="document.getElementById('fileInput').click()">Importar</button>
      </div>

      <!-- Lista de certificados -->
      <div class="cert-list">
      <?php
session_start();
require_once "../php/conexao.php";

$idAluno = $_SESSION['idAluno'] ?? null;

if(!$idAluno){
    echo "<p>Usuário não logado.</p>";
    exit;
}

$sql = "SELECT * FROM certificados WHERE idAluno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idAluno);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        echo '<div class="cert-item">';
        echo '<strong>'.htmlspecialchars($row['titulo']).'</strong>';
        echo '<small>Horas: '.$row['quantidadeHoras'].' | Data: '.$row['dataEmissao'].'</small>';
        echo '<br><a href="../'.$row['URL'].'" target="_blank">Ver Certificado</a>';

        // Botão de excluir
        echo '<form method="POST" action="../php/excluir_certificado.php" style="display:inline">';
        echo '<input type="hidden" name="idCertificado" value="'.$row['idCertificado'].'">';
        echo '<button type="submit" class="btn danger" onclick="return confirm(\'Deseja realmente excluir este certificado?\')">Excluir</button>';
        echo '</form>';

        echo '</div>';
    }
} else {
    echo "<p>Nenhum certificado encontrado.</p>";
}
?>

</div>
    </div>
  </main>

  <!-- Modal do formulário -->
  <div class="form-modal" id="formModal">
    <div class="form-box">
      <h2>Informações do Arquivo</h2>
      <form id="uploadForm" action="../php/upload.php" method="POST" enctype="multipart/form-data">
        <label>Evento</label>
        <input type="text" name="curso" id="cursoInput" required>

        <label>Horas</label>
        <input type="number" name="horas" id="horasInput" min="1" required>

        <label>Data do Evento</label>
        <input type="date" name="data" id="dataInput" required>

        <input type="file" name="arquivo" id="fileInput" style="display:none" required>

        <div class="form-actions">
          <button type="button" class="btn secondary" onclick="closeForm()">Cancelar</button>
          <button type="submit" class="btn">Salvar</button>
        </div>
      </form>
    </div>
  </div>

<script src="../js/certificados.js"></script>
</body>
</html>
