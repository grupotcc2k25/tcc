<?php
session_start();
require_once "conexao.php";

$idAluno = $_SESSION['idAluno'] ?? null;
if(!$idAluno){
    die("Usuário não logado.");
}

$idCertificado = $_POST['idCertificado'] ?? null;
if(!$idCertificado){
    die("ID do certificado não fornecido.");
}

// Primeiro, pega o caminho do arquivo para excluir fisicamente
$sql = "SELECT URL FROM certificados WHERE idCertificado = ? AND idAluno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $idCertificado, $idAluno);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows === 1){
    $row = $result->fetch_assoc();
    $arquivo = __DIR__ . "/../" . $row['URL']; // caminho físico

    if(file_exists($arquivo)){
        unlink($arquivo); // exclui o arquivo da pasta
    }

    // Agora exclui do banco
    $sqlDelete = "DELETE FROM certificados WHERE idCertificado = ? AND idAluno = ?";
    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bind_param("ii", $idCertificado, $idAluno);
    $stmtDelete->execute();
    $stmtDelete->close();

    header("Location: ../html/certificados.php"); // volta pra listagem
    exit;
} else {
    die("Certificado não encontrado ou você não tem permissão.");
}

$conn->close();
?>
