<?php
session_start();
require_once "conexao.php";

$idAluno = $_SESSION['idAluno'] ?? null;
if(!$idAluno){
    die("Usuário não logado.");
}

$titulo = $_POST['curso'] ?? '';
$data   = $_POST['data'] ?? '';
$horas  = $_POST['horas'] ?? '';
$instituicao = "Minha Instituição";

// Caminho da pasta de uploads (já criada)
$uploadDir = __DIR__ . "/../uploads"; // ../ porque upload.php está em php/
$nomeArquivo = uniqid() . "-" . basename($_FILES['arquivo']['name']);
$destinoFisico = $uploadDir . "/" . $nomeArquivo;

// Caminho que vai para o banco (relativo à pasta pública)
$destinoDB = "uploads/" . $nomeArquivo;

if(isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] == 0){
    if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $destinoFisico)){
        $sql = "INSERT INTO certificados (titulo, dataEmissao, URL, quantidadeHoras, instituicao, idAluno) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if(!$stmt){
            die("Erro na query: " . $conn->error);
        }

        $stmt->bind_param("sssisi", $titulo, $data, $destinoDB, $horas, $instituicao, $idAluno);

        if($stmt->execute()){
            header("Location: ../html/certificados.php"); // volta pra listagem
            exit;
        } else {
            echo "Erro ao salvar no banco: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Erro ao mover o arquivo. Verifique permissões da pasta uploads.";
    }
} else {
    echo "Nenhum arquivo enviado ou erro no upload.";
}

$conn->close();
?>
