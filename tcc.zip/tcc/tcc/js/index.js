function trocarLabel() {
  const select = document.getElementById("format");
  const label = document.querySelector("#inputUsuario");
  const input = document.querySelector("#inputUsuario");
  const senhaInput = document.querySelector("#inputSenha");

  const rmErro = document.querySelector(".rmErro");
  const loginErro = document.querySelector(".loginErro");
  const cnpjErro = document.querySelector(".cnpjErro");
  const senhaErro = document.querySelector(".senhaErro");

  const tipo = select.value;

  input.disabled = false;
  senhaInput.disabled = false;
  input.value = "";
  senhaInput.value = "";

  rmErro.style.display = "none";
  loginErro.style.display = "none";
  cnpjErro.style.display = "none";
  senhaErro.style.display = "none";

  input.removeEventListener("input", validarRM);
  input.removeEventListener("input", validarTexto);
  input.removeEventListener("input", aplicarMascaraCNPJ);
  input.removeEventListener("keypress", bloquearNaoNumeros);

  if (tipo === "alunos") {
    input.placeholder = "Digite seu RM";
    input.maxLength = 5;
    input.addEventListener("input", validarRM);
    input.addEventListener("keypress", bloquearNaoNumeros);
  } else if (tipo === "coordenacao") {
    input.placeholder = "Digite seu login";
    input.maxLength = 8;
    input.addEventListener("input", validarTexto);
    input.addEventListener("keypress", bloquearNaoNumeros);
  } else if (tipo === "empresas") {
    input.placeholder = "Digite o CNPJ";
    input.maxLength = 18;
    input.addEventListener("input", aplicarMascaraCNPJ);
    input.addEventListener("input", validarTexto);
    input.addEventListener("keypress", bloquearNaoNumeros);
  }

  validarCampos();
}

function bloquearNaoNumeros(e) { if(!/\d/.test(e.key)) e.preventDefault(); }

function validarRM() {
  const rm = document.querySelector("#inputUsuario").value;
  document.querySelector(".rmErro").style.display = /^\d{5}$/.test(rm) || rm==="" ? "none" : "block";
  validarCampos();
}

function validarTexto() {
  const usuario = document.querySelector("#inputUsuario").value;
  const tipo = document.getElementById("format").value;
  const loginErro = document.querySelector(".loginErro");
  const cnpjErro = document.querySelector(".cnpjErro");

  loginErro.style.display = "none";
  cnpjErro.style.display = "none";

  if(tipo==="coordenacao" && usuario!=="" && !/^\d{8}$/.test(usuario)) loginErro.style.display="block";
  if(tipo==="empresas"){
    const cnpjLimpo = usuario.replace(/\D/g,"");
    if(cnpjLimpo!=="" && !/^\d{14}$/.test(cnpjLimpo)) cnpjErro.style.display="block";
  }

  validarCampos();
}

function validarSenha() {
  const senha = document.querySelector("#inputSenha").value;
  document.querySelector(".senhaErro").style.display = senha.length>=7 || senha==="" ? "none":"block";
  validarCampos();
}

function validarCampos() {
  const tipo = document.getElementById("format").value;
  const usuario = document.querySelector("#inputUsuario").value;
  const senha = document.querySelector("#inputSenha").value;
  const botao = document.querySelector(".botaoEntrar");

  let usuarioValido=false;
  if(tipo==="alunos") usuarioValido=/^\d{5}$/.test(usuario);
  else if(tipo==="coordenacao") usuarioValido=/^\d{8}$/.test(usuario);
  else if(tipo==="empresas"){
    const cnpjLimpo = usuario.replace(/\D/g,"");
    usuarioValido=/^\d{14}$/.test(cnpjLimpo);
  }

  botao.disabled = !(usuarioValido && senha.length>=7);
}

function redirecionar() {
  const tipo=document.getElementById("format").value;
  const usuario=document.querySelector("#inputUsuario").value;
  const senha=document.querySelector("#inputSenha").value;
  const cnpjLimpo=usuario.replace(/\D/g,"");

  if((tipo==="alunos" && /^\d{5}$/.test(usuario)) ||
     (tipo==="coordenacao" && /^\d{8}$/.test(usuario)) ||
     (tipo==="empresas" && /^\d{14}$/.test(cnpjLimpo))) {
    document.querySelector(".formLogin").submit();
  }
}

function aplicarMascaraCNPJ(e) {
  let valor=e.target.value.replace(/\D/g,"");
  if(valor.length>14) valor=valor.slice(0,14);

  let formatado=valor;
  if(valor.length>2) formatado=valor.slice(0,2)+"."+valor.slice(2);
  if(valor.length>5) formatado=formatado.slice(0,6)+"."+formatado.slice(6);
  if(valor.length>8) formatado=formatado.slice(0,10)+"/"+formatado.slice(10);
  if(valor.length>12) formatado=formatado.slice(0,15)+"-"+formatado.slice(15);

  e.target.value=formatado;
}

document.addEventListener("DOMContentLoaded",()=>{
  const inputUsuario=document.querySelector("#inputUsuario");
  const inputSenha=document.querySelector("#inputSenha");
  const botao=document.querySelector(".botaoEntrar");

  inputUsuario.value="";
  inputSenha.value="";
  inputUsuario.addEventListener("input", validarRM);
  inputSenha.addEventListener("input", validarSenha);
  inputUsuario.addEventListener("keypress", bloquearNaoNumeros);

  document.addEventListener("keydown", function(e){
    if(e.key==="Enter"){ e.preventDefault(); if(!botao.disabled) botao.click(); }
    if(e.ctrlKey && e.key.toLowerCase()==="l"){ e.preventDefault(); inputUsuario.focus(); }
    if(e.ctrlKey && e.key.toLowerCase()==="s"){ e.preventDefault(); inputSenha.focus(); }
    if(e.key==="Escape"){ 
      inputUsuario.value=""; inputSenha.value="";
      document.querySelectorAll(".rmErro,.loginErro,.cnpjErro,.senhaErro").forEach(el=>el.style.display="none");
      validarCampos();
    }
  });

  botao.addEventListener("click", redirecionar);

  // BLOQUEIO BOTÃO VOLTAR
  history.pushState(null,null,location.href);
  window.addEventListener("popstate",()=>history.pushState(null,null,location.href));
});
