document.addEventListener('DOMContentLoaded', function() {
    // Garante que o script só execute após o carregamento completo do DOM.

    // === Elementos do DOM ===
    // Armazena referências aos elementos HTML que serão manipulados.
    const originalSelectTipoUsuario = document.getElementById('tipo_usuario'); // O select original (escondido)
    const customSelectWrapper = document.getElementById('customTipoUsuario'); // O container do select customizado
    const customSelectDisplay = customSelectWrapper.querySelector('.custom-select-display'); // Onde o valor selecionado é exibido no custom select
    const customSelectOptions = customSelectWrapper.querySelector('.custom-select-options'); // A lista de opções do custom select

    const inputIdentificacao = document.getElementById('identificacao'); // Campo de input para identificação (RM, Login, CNPJ)
    const labelIdentificacao = document.getElementById('label-identificacao'); // O label associado ao campo de identificação
    const inputSenha = document.getElementById('senha'); // Campo de input para a senha
    const btnSubmit = document.querySelector('.btn'); // O botão de submit do formulário
    const loginForm = document.getElementById('loginForm'); // O formulário de login

    // === Funções Auxiliares ===

    /**
     * Verifica se o jQuery Mask Plugin está disponível e aplica a máscara de CNPJ.
     * PREVENÇÃO DE CONFLITO: Garante que `$.fn.mask` exista antes de chamar.
     */
    function aplicarMascaraCNPJ() {
        if (typeof $.fn.mask === 'function') {
            $('#identificacao').mask('00.000.000/0000-00', {reverse: true});
        } else {
            console.warn('jQuery Mask Plugin não encontrado. A máscara de CNPJ não será aplicada.');
        }
    }

    /**
     * Verifica se o jQuery Mask Plugin está disponível e aplica a máscara de RM.
     * PREVENÇÃO DE CONFLITO: Garante que `$.fn.mask` exista antes de chamar.
     */
    function aplicarMascaraRM() {
        if (typeof $.fn.mask === 'function') {
            $('#identificacao').mask('00000');
        } else {
            console.warn('jQuery Mask Plugin não encontrado. A máscara de RM não será aplicada.');
        }
    }

    /**
     * Verifica se o jQuery Mask Plugin está disponível e remove qualquer máscara aplicada.
     * PREVENÇÃO DE CONFLITO: Garante que `$.fn.unmask` exista antes de chamar.
     */
    function removerMascaras() {
        if (typeof $.fn.unmask === 'function') {
            $('#identificacao').unmask();
        } else {
            // Não é um erro crítico se unmask não existir, apenas significa que não há máscara para remover
            // ou o plugin não foi carregado.
        }
    }

    // Função principal para ajustar os atributos e o estado dos campos de input
    // com base no tipo de usuário selecionado.
    function updateInputFieldAttributes() {
        const tipo = originalSelectTipoUsuario.value; // Obtém o valor do tipo de usuário selecionado

        if (tipo === "") {
            // Se "Selecione uma opção" (placeholder) estiver selecionado:
            inputIdentificacao.disabled = true; // Desabilita o campo de identificação
            inputIdentificacao.value = ''; // Limpa o valor do campo
            inputIdentificacao.placeholder = 'Selecione o tipo de usuário primeiro'; // Define um placeholder informativo
            labelIdentificacao.textContent = 'Identificação'; // Define um label genérico
            removerMascaras(); // Garante que nenhuma máscara esteja ativa

            inputSenha.disabled = true; // Desabilita o campo de senha
            inputSenha.value = ''; // Limpa a senha
            btnSubmit.disabled = true; // Desabilita o botão de submit
            
            // Reseta o contador de caracteres da senha, se existir.
            if(document.getElementById('senha-counter')) {
                document.getElementById('senha-counter').textContent = '0/20';
            }
        } else {
            // Se um tipo de usuário válido for selecionado:
            inputIdentificacao.disabled = false; // Habilita o campo de identificação
            inputSenha.disabled = false; // Habilita o campo de senha
            btnSubmit.disabled = false; // Habilita o botão de submit
            
            inputIdentificacao.value = ''; // Limpa o valor ao mudar o tipo de usuário
            removerMascaras(); // Remove máscaras antigas antes de aplicar uma nova

            // Usa um switch para configurar os campos com base no tipo de usuário.
            switch(tipo) {
                case 'aluno':
                    labelIdentificacao.textContent = 'RM'; // Altera o label para "RM"
                    inputIdentificacao.placeholder = 'Digite seu RM (5 dígitos)'; // Placeholder específico
                    inputIdentificacao.maxLength = 5; // Define o comprimento máximo
                    inputIdentificacao.pattern = "\\d{5}"; // Padrão de validação (5 dígitos)
                    inputIdentificacao.type = "text"; // Tipo de input
                    inputIdentificacao.inputMode = "numeric"; // Sugere teclado numérico em dispositivos móveis
                    aplicarMascaraRM(); // Aplica a máscara de RM
                    break;
                    
                case 'coordenacao':
                    labelIdentificacao.textContent = 'Login'; // Altera o label para "Login"
                    inputIdentificacao.placeholder = 'Digite seu Login (8 caracteres)'; // Placeholder específico
                    inputIdentificacao.maxLength = 8; // Define o comprimento máximo
                    inputIdentificacao.pattern = "[a-zA-Z0-9]{8}"; // Padrão (8 caracteres alfanuméricos)
                    inputIdentificacao.type = "text"; // Tipo de input
                    inputIdentificacao.inputMode = "text"; // Sugere teclado de texto
                    // Não há máscara para login alfanumérico.
                    break;
                    
                case 'empresa':
                    labelIdentificacao.textContent = 'CNPJ'; // Altera o label para "CNPJ"
                    inputIdentificacao.placeholder = 'Digite seu CNPJ'; // Placeholder específico
                    inputIdentificacao.maxLength = 18; // Define o comprimento máximo (com a máscara)
                    inputIdentificacao.pattern = "\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}\\-\\d{2}"; // Padrão de validação para CNPJ
                    inputIdentificacao.type = "text"; // Tipo de input
                    inputIdentificacao.inputMode = "numeric"; // Sugere teclado numérico
                    aplicarMascaraCNPJ(); // Aplica a máscara de CNPJ
                    break;
            }
        }
    }

    // === Lógica de Inicialização e Eventos ===

    // Inicializa o display do custom select com o texto do placeholder.
    // PREVENÇÃO DE CONFLITO: A cor é definida via JS para simular o placeholder,
    // e o JS também a remove quando uma opção é selecionada.
    const initialSelectedOptionText = originalSelectTipoUsuario.querySelector('option[value=""]').textContent;
    customSelectDisplay.textContent = initialSelectedOptionText;
    customSelectDisplay.style.color = 'rgba(200, 200, 200, 0.5)'; // Estilo de placeholder
    
    // Configura os atributos iniciais dos campos (desabilitados) ao carregar a página.
    updateInputFieldAttributes();


    // Event listener para o clique no display do dropdown customizado.
    customSelectDisplay.addEventListener('click', function() {
        // Fecha outros dropdowns customizados abertos para evitar múltiplos abertos.
        document.querySelectorAll('.custom-select-options.open').forEach(openDropdown => {
            if (openDropdown !== customSelectOptions) {
                openDropdown.classList.remove('open');
                openDropdown.previousElementSibling.classList.remove('open');
            }
        });

        // PREVENÇÃO DE CONFLITO: O JS controla a classe 'open' para visibilidade e estilo.
        // Certifique-se de que nenhum CSS externo force 'display' ou 'opacity' para esses elementos.
        customSelectOptions.classList.toggle('open'); // Alterna a visibilidade das opções
        this.classList.toggle('open'); // Adiciona/remove classe 'open' no display para estilos
    });

    // Event listener para cliques nas opções customizadas.
    customSelectOptions.querySelectorAll('li').forEach(optionLi => {
        optionLi.addEventListener('click', function() {
            const selectedValue = this.dataset.value; // Obtém o valor da opção clicada (do atributo data-value)
            const selectedText = this.textContent; // Obtém o texto visível da opção

            // Atualiza o select original escondido com o valor selecionado.
            originalSelectTipoUsuario.value = selectedValue;
            // Dispara um evento 'change' no select original para simular uma mudança real.
            originalSelectTipoUsuario.dispatchEvent(new Event('change')); 

            // Atualiza o texto visível do custom select e remove o estilo de placeholder.
            customSelectDisplay.textContent = selectedText;
            customSelectDisplay.style.color = 'var(--text-color)'; // Reverte para a cor de texto normal.

            // Remove a classe 'selected' de todas as opções e adiciona à opção clicada.
            // PREVENÇÃO DE CONFLITO: O JS controla a classe 'selected' para indicar a opção ativa.
            customSelectOptions.querySelectorAll('li').forEach(li => li.classList.remove('selected'));
            this.classList.add('selected');

            // Fecha o dropdown customizado.
            customSelectOptions.classList.remove('open');
            customSelectDisplay.classList.remove('open');

            // Após a seleção, atualiza os atributos e estado dos campos de identificação e senha.
            updateInputFieldAttributes(); 
        });
    });

    // Fecha o dropdown customizado se o usuário clicar fora dele.
    document.addEventListener('click', function(event) {
        // Verifica se o clique não foi dentro do wrapper do custom select nem nas suas partes.
        if (!customSelectWrapper.contains(event.target) && event.target !== customSelectDisplay && event.target !== customSelectOptions) {
            customSelectOptions.classList.remove('open');
            customSelectDisplay.classList.remove('open');
        }
    });

    // === Validação do formulário ===
    loginForm.addEventListener('submit', function(e) {
        const tipo = originalSelectTipoUsuario.value; // Tipo de usuário selecionado
        let valorIdentificacao = inputIdentificacao.value; // Valor atual do campo de identificação
        
        // Se não for "empresa", remove caracteres não numéricos para validação de comprimento.
        // Isso é importante para que a validação de `length` seja precisa,
        // independentemente da máscara aplicada que adiciona pontos/barras/hífens.
        if (tipo !== 'empresa') { 
            valorIdentificacao = valorIdentificacao.replace(/\D/g, ''); 
        } else {
            // Para empresa, remove *todos* os não-dígitos para obter o CNPJ puro (14 dígitos).
            valorIdentificacao = valorIdentificacao.replace(/\D/g, '');
        }

        const valorSenha = inputSenha.value; // Valor da senha

        // Validação: tipo de usuário não selecionado.
        if (tipo === "") {
            alert('Por favor, selecione um tipo de usuário!');
            e.preventDefault(); // Impede o envio do formulário
            return;
        }

        // Validação específica para Aluno (RM).
        if (tipo === 'aluno' && valorIdentificacao.length !== 5) {
            alert('RM deve conter exatamente 5 dígitos!');
            e.preventDefault();
            return;
        }
        
        // Validação específica para Coordenação (Login).
        if (tipo === 'coordenacao' && valorIdentificacao.length !== 8) {
            alert('Login deve conter exatamente 8 caracteres!');
            e.preventDefault();
            return;
        }
        
        // Validação específica para Empresa (CNPJ).
        // Aqui, o CNPJ puro deve ter 14 dígitos.
        if (tipo === 'empresa' && valorIdentificacao.length !== 14) { 
            alert('CNPJ deve conter exatamente 14 dígitos!');
            e.preventDefault();
            return;
        }
        
        // Validação para comprimento máximo da senha.
        if (valorSenha.length > 20) {
            alert('A senha não pode ter mais de 20 caracteres!');
            e.preventDefault();
            return;
        }
    });

    // === Impede a entrada de caracteres não permitidos na identificação ===
    inputIdentificacao.addEventListener('keydown', function(e) {
        const tipo = originalSelectTipoUsuario.value;

        // Se o campo estiver desabilitado (placeholder ativo), impede qualquer entrada.
        if (this.disabled) {
            e.preventDefault();
            return false;
        }
        
        // Permite teclas de controle (Backspace, Tab, Esc, Enter, setas, Ctrl+A).
        if ([46, 8, 9, 27, 13].includes(e.keyCode) || 
            (e.keyCode === 65 && e.ctrlKey === true) || 
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
        }
        
        // Permite caracteres de formatação para CNPJ (ponto, barra, hífen).
        // Isso é importante para que o usuário possa digitar a máscara se a máscara falhar por algum motivo.
        if (tipo === 'empresa' && 
            ([190, 191, 189].includes(e.keyCode) || e.key === '.' || e.key === '/' || e.key === '-')) {
            return;
        }
        
        // Restringe entrada de caracteres com base no tipo de usuário.
        if (tipo === 'aluno' || tipo === 'coordenacao') {
             if (!((e.keyCode >= 48 && e.keyCode <= 57) || // Permite números (teclado principal)
                   (e.keyCode >= 96 && e.keyCode <= 105) || // Permite números (numpad)
                   (tipo === 'coordenacao' && e.keyCode >= 65 && e.keyCode <= 90))) { // Permite letras para coordenação
                e.preventDefault(); // Impede o caractere de ser digitado
            }
        }
    });

    // === Contador de caracteres da senha (opcional) ===
    // Verifica se o elemento do contador de senha existe.
    if(document.getElementById('senha-counter')) {
        inputSenha.addEventListener('input', function(e) {
            const counter = document.getElementById('senha-counter'); // O elemento do contador
            counter.textContent = `${e.target.value.length}/20`; // Atualiza o texto do contador
            
            // Altera a cor do contador se a senha exceder 20 caracteres.
            if (e.target.value.length > 20) {
                counter.style.color = 'var(--error-color)'; // Cor de erro
            } else {
                counter.style.color = 'var(--secondary-color)'; // Cor normal
            }
        });
    }
});