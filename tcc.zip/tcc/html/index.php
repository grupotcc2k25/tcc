<?php
// Inicia a sessão (se necessário)
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Login</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <link rel="stylesheet" href="../css/style_index.css">
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>Login</h1>
        </div>
        
        <form action="autenticar.php" method="POST" id="loginForm">
            <div class="form-group">
                <label for="tipo_usuario">Tipo de Usuário</label>
                <select class="form-control" id="tipo_usuario" name="tipo_usuario" required 
                        oninvalid="this.setCustomValidity('Por favor, selecione uma opção')" 
                        onchange="this.setCustomValidity('')" style="display: none;">
                    <option value="" disabled selected hidden>Selecione uma opção</option>
                    <option value="aluno">Aluno</option>
                    <option value="coordenacao">Coordenação</option>
                    <option value="empresa">Empresa</option>
                </select>

                <div class="custom-select-wrapper" id="customTipoUsuario">
                    <div class="custom-select-display form-control" tabindex="0">
                        Selecione uma opção <span class="arrow-icon"></span> </div>
                    <ul class="custom-select-options">
                        <li data-value="aluno">Aluno</li>
                        <li data-value="coordenacao">Coordenação</li>
                        <li data-value="empresa">Empresa</li>
                    </ul>
                </div>
            </div>
            
            <div class="form-group" id="campo-identificacao">
                <label for="identificacao" id="label-identificacao">RM</label>
                <input type="text" class="form-control" id="identificacao" name="identificacao" 
                        placeholder="Digite seu RM" required maxlength="5" pattern="\d{5}">
            </div>
            
            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" 
                        placeholder="Digite sua senha (máx. 20 caracteres)" 
                        required maxlength="20">
            </div>
            
            <button type="submit" class="btn">Entrar</button>
        </form>
        
        <div class="footer">
            <p>Problemas para acessar? <a href="#">Contate o suporte</a></p>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script src="../js/index.js"></script>
</body>
</html>