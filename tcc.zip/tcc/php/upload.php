<?php
session_start();
require_once "conexao.php";

$idAluno   = $_SESSION['idAluno'] ?? null;
$rmAluno   = $_SESSION['rm'] ?? null;   // RM do aluno
$nomeAluno = $_SESSION['nome'] ?? null; // Nome do aluno

if(!$idAluno || !$rmAluno){
    die("Usuário não logado.");
}

$titulo = $_POST['curso'] ?? '';
$data   = $_POST['data'] ?? '';
$horas  = $_POST['horas'] ?? '';
$instituicao = "3°AMS Ourinhos";

// Upload do arquivo
if(isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] == 0){
    // Caminho físico real: tcc/uploads
    $uploadDir = __DIR__ . "/../uploads"; 
    if(!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    // Extensão original do arquivo
    $extensao = pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION);

    // Novo nome do arquivo: RM_NomeAluno_Curso.ext
    $nomeArquivo = $rmAluno . "_" 
                 . preg_replace('/[^A-Za-z0-9_-]/', '_', $nomeAluno) . "_" 
                 . preg_replace('/[^A-Za-z0-9_-]/', '_', $titulo) 
                 . "." . $extensao;

    // Caminho físico para salvar
    $destinoFisico = $uploadDir . "/" . $nomeArquivo;

    // Caminho relativo para salvar no banco (pra abrir no navegador)
    $urlBanco = "uploads/" . $nomeArquivo;

    if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $destinoFisico)){
        $sql = "INSERT INTO certificados (titulo, dataEmissao, URL, quantidadeHoras, instituicao, idAluno) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if(!$stmt){
            die("Erro na query: " . $conn->error);
        }

        $stmt->bind_param("sssisi", $titulo, $data, $urlBanco, $horas, $instituicao, $idAluno);

        if($stmt->execute()){
            header("Location: ../html/certificados.php");
            exit;
        } else {
            echo "Erro ao salvar no banco: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Erro ao mover o arquivo.";
    }
} else {
    echo "Nenhum arquivo enviado ou erro no upload.";
}

$conn->close();
?>
