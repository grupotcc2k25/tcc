<?php
$senha = "12345678";
$hash = password_hash($senha, PASSWORD_DEFAULT);
echo "Hash gerado para a senha '12345678':<br><code>$hash</code>";
?>